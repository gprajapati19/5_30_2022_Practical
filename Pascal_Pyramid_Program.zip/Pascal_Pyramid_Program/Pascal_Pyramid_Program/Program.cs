﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pascal_Pyramid_Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int i, j;


            /* Program for below pattern
                *
                **
                ***
                ****
                *****
                ******
            */

            /* for (i=1; i<=6;++i)
             {           
                 for (j = 1; j <= i; ++j)
                 {
                     Console.Write("*");
                 }
                 Console.WriteLine();
             }*/

            /* Program for below pattern
                     *
                    **
                   ***
                  ****
                 *****
                ******
            */

            /*
                       int i, j, k;
                       int n = 6;
                       // loop to print the series
                       for (i = 1; i <= n; i++)
                       {
                           for (j = 1; j <= n - i; j++)
                           {
                               Console.Write(" ");
                           }
                           for (k = 1; k <= i; k++)
                              {
                                  Console.Write("*");
                              }
                           Console.WriteLine("");
                       }
                       Console.ReadLine();*/

            /* Program for below pattern
                 *
                ***
               *****
              *******
             *********
            ***********
             *********
              *******
               *****
                ***
                 *
            */


            /*int a = 1, spaces, k = 6, i = 0, j = 0;
            spaces = k - 1;
            for (i = 1; i < k * 2; i++)
            {
                for (j = 1; j <= spaces; j++)
                {
                    Console.Write(" ");
                }
                for (j = 1; j < a * 2; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine("");
                if (i < k)
                {
                    spaces--;
                    a++;
                }
                else
                {
                    spaces++;
                    a--;
                }
            }*/


            /* Program for below pattern
                        1
                       121
                      12321
                     1234321
                    123454321
            */

            /*int num, space;

            while (true)
            {
                Console.Write("Enter a number between 1 to 9 : ");

                num = Convert.ToInt32(Console.ReadLine());

                space = num - 1;

                for (int i = 1; i <= num; i++)
                {
                    for (space = 1; space <= (num - i); space++)
                    {
                        Console.Write(" ");
                    }
                    
                    for (int j = 1; j <= i; j++)
                    {
                        Console.Write(j);
                    }

                    for (int k = (i - 1); k >= 1; k--)
                    {
                        Console.Write(k);
                    }

                    Console.WriteLine();

                }
              }*/

            

            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(i);
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
