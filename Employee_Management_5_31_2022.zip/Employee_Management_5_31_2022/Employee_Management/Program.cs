﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Management
{

    public class Employee 
    {
        public string EmpName { get; set; }
        public string EmpNo { get; set; }
        public string EmpPhone { get; set; }
        public string EmpCity { get; set; }
        public string EmpExp { get; set; }

        public void menu()
        {
            
            Console.WriteLine("1.Add Employee");
            Console.WriteLine("2.Edit Employee");
            Console.WriteLine("3.Search for Employee");
            Console.WriteLine("4.Show all Employees");
            Console.WriteLine("5.Delete Employee");
            Console.WriteLine("6.Exit Program \n"); 
        }

    }
    public class Program
    {
   
        public static void Main(string[] args)
        {

          List<Employee> emplist = new List<Employee>();

          Employee emp = new Employee();

          Console.WriteLine("***Welcome to Employee Management*** \n");

          startconsole:

            emp.menu();

            Console.Write("Select any option : ");
            

            int option = Convert.ToInt16(Console.ReadLine());

            if (option == 1)
            {
                Console.WriteLine("\n");
                Console.Write("Enter Employee Name : ");
                string EmpName1 = Console.ReadLine();

                Console.Write("Enter Employee No :");
                string EmpNo1 = Console.ReadLine();

                Console.Write("Enter Employee Phone Number :");
                string EmpPhone1 = Console.ReadLine();

                Console.Write("Enter Employee City : ");
                string EmpCity1 = Console.ReadLine();

                Console.Write("Enter Employee Year of Experiance : ");
                string EmpExp1 = Console.ReadLine();

                Console.WriteLine("Employee Detail Inserted Successfully \n");

                emplist.Add(new Employee
                {
                    EmpName = EmpName1,
                    EmpNo = EmpNo1,
                    EmpPhone = EmpPhone1,
                    EmpCity = EmpCity1,
                    EmpExp = EmpExp1,
                });
            }
            else if (option == 2)
            {
              
                Console.Write("Enter the Employee Name to edit : ");
                string employeeName1 = Console.ReadLine();

                //foreach (var emedit in emplist.Where(x => x.EmpName == employeeName1))

                if (emplist.Count > 0)
                {

                    foreach (Employee emedit in emplist)
                    {
                            Console.Write("Enter Employee Name : ");
                            string EmpName1 = Console.ReadLine();

                            Console.Write("Enter Employee No :");
                            string EmpNo1 = Console.ReadLine();

                            Console.Write("Enter Employee Phone Number :");
                            string EmpPhone1 = Console.ReadLine();

                            Console.Write("Enter Employee City : ");
                            string EmpCity1 = Console.ReadLine();

                            Console.Write("Enter Employee Year of Experiance : ");
                            string EmpExp1 = Console.ReadLine();

                            Console.WriteLine("Employee Detail Updated Successfully \n");
                            emedit.EmpName = EmpName1;
                            emedit.EmpNo = EmpNo1;
                            emedit.EmpPhone = EmpPhone1;
                            emedit.EmpCity = EmpCity1;
                            emedit.EmpExp = EmpExp1;
                    }
                }
                else 
                {
                    Console.WriteLine("\nThe Employee does not exist!\n");
                }

            }

            else if (option == 3)
            {
                Console.Write("Enter the Employee Name or No to search: ");
                string employeeName = Console.ReadLine();
                bool exist = false;
                foreach (Employee e in emplist)
                {
                    if (e.EmpName == employeeName || e.EmpNo == employeeName)
                    {
                        Console.WriteLine("Employee Details \n");
                        Console.WriteLine("EmpName" + "\t" + "EmpNo" + "\t" + "Emp PhoneNo" + "\t" + "EmpCity" + "\t" + "EmpCity" + "\n");
                        Console.WriteLine("---------------------------------------------------------------");
                        Console.WriteLine(e.EmpName + "\t" + e.EmpNo + "\t" + e.EmpPhone + "\t" + e.EmpCity + "\t" + e.EmpExp);
                        exist = true;
                        break;
                    }
                }
                if (!exist)
                {
                    Console.WriteLine("\nThe Employee does not exist!\n");
                }
            }
            else if (option == 4)
            {
                if (emplist.Count == 0)
                {
                    Console.WriteLine("There is no employee details");
                }
                else
                {
                    Console.WriteLine("Employee Details \n");
                    Console.WriteLine("EmpName" + "\t" + "EmpNo" + "\t" + "Emp PhoneNo" + "\t" + "EmpCity" + "\t" + "EmpCity" + "\n");
                    Console.WriteLine("---------------------------------------------------------------");
                    foreach (Employee empdata in emplist)
                    {

                        Console.WriteLine(empdata.EmpName + "\t" + empdata.EmpNo + "\t" + empdata.EmpPhone + "\t" + empdata.EmpCity + "\t" + empdata.EmpExp + "\n");
                    }
                }
            }

            else if (option == 5)
            {

                Console.Write("Enter the Employee Name OR No to delete:");
                string employeeName = Console.ReadLine();
                bool exist = false;
                foreach (Employee e in emplist)
                {
                    if (e.EmpName == employeeName || e.EmpNo == employeeName)
                    {
                        emplist.Remove(e);
                        exist = true;
                        Console.Write(e.EmpName + " \t Employee Detail deleted successfully \n ");
                        break;
                    }
                    else
                    {
                        Console.WriteLine("The Employee Name does not exist!\n");
                    }
                }
                if (!exist)
                {
                    Console.WriteLine("The Employee Name does not exist!\n");
                }

            }

            else if (option == 6)
            {
                System.Environment.Exit(0);
            }
            
            Console.WriteLine("Do you want to repeat the option Y / N ?");
            string optionresult = Console.ReadLine().ToUpper();

            optionresult = optionresult.ToLower();
            if (optionresult == "Y" || optionresult == "y")
            {
                goto startconsole;
            }
            

        }  
        
        
    }
}
