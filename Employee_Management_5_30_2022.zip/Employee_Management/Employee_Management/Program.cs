﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Management
{

    public class Employee 
    {
        public string EmpName { get; set; }
        public string EmpNo { get; set; }
        public string EmpPhone { get; set; }
        public string EmpCity { get; set; }
        public string EmpExp { get; set; }

        public void menu()
        {
            Console.Write("Enter your option : \n");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2.Edit Employee");
            Console.WriteLine("3.Search for Employee");
            Console.WriteLine("4.Show all Employees");
            Console.WriteLine("5.Delete Employee");
            Console.WriteLine("6.Exit Program \n"); 
        }

    }
    public class Program
    {
   
        public static void Main(string[] args)
        {

           List<Employee> emplist = new List<Employee>();

           Employee emp = new Employee();

           

            Console.WriteLine("***Welcome to Employee Management*** \n");

        startconsole:

            emp.menu();

            Console.Write("Select any option : ");
            

            int option = Convert.ToInt16(Console.ReadLine());

            if (option == 1)
            {
                Console.WriteLine("\n");
                Console.Write("Enter Employee Name : ");
                string EmpName1 = Console.ReadLine();

                Console.Write("Enter Employee No :");
                string EmpNo1 = Console.ReadLine();

                Console.Write("Enter Employee Phone Number :");
                string EmpPhone1 = Console.ReadLine();

                Console.Write("Enter Employee City : ");
                string EmpCity1 = Console.ReadLine();

                Console.Write("Enter Employee Year of Experiance : ");
                string EmpExp1 = Console.ReadLine();


                Console.WriteLine("Employee Detail Inserted Successfully \n");
                emplist.Add(new Employee
                {
                    EmpName = EmpName1,
                    EmpNo = EmpNo1,
                    EmpPhone = EmpPhone1,
                    EmpCity = EmpCity1,
                    EmpExp = EmpExp1,
                });
            }
            else if (option==3)
            {
                Console.Write("Enter the Employee Number Name to search: ");
                string employeeNumber = Console.ReadLine();
                foreach (Employee e in emplist)
                {
                    if (e.EmpName == employeeNumber)
                    {
                        Console.WriteLine(e.EmpName, e.EmpNo, e.EmpPhone,e.EmpCity, e.EmpExp);
                        //Console.WriteLine(e.ToString());
                        
                    }
                    else
                    {
                        Console.WriteLine("\nThe Employee does not exist!\n");
                    }
                }
              
               
            }
            

            else if (option == 4)
            {
                if (emplist.Count == 0)
                {
                    Console.WriteLine("There is no employee details");
                }
                else
                {
                    Console.WriteLine("Employee Details \n");
                    Console.WriteLine("Emp Name" + "\t" + "Emp No" + "\t" + "Emp Phone No" + "\t" + "Emp City" + "\t" + "Emp City" + "\n");
                    Console.WriteLine("---------------------------------------------------------------");
                    foreach (Employee empdata in emplist)
                    {
                        
                        Console.WriteLine(empdata.EmpName + "\t" + empdata.EmpNo + "\t" + empdata.EmpPhone + "\t" + empdata.EmpCity + "\t" + empdata.EmpExp + "\n");
                    }
                }
            }

            else if (option == 5) 
            {
                
                    Console.Write("Enter the Employee Name to delete:");
                    string employeeNumber = Console.ReadLine();
                    //bool exist = false;
                    foreach (Employee e in emplist)
                    {
                        if (e.EmpName == employeeNumber)
                        {
                            emplist.Remove(e);
                            //exist = true;
                            Console.Write("Employee Detail deleted successfully \n ");
                            break;
                        }
                        else
                        {
                            Console.WriteLine("The Employee Name does not exist!\n");
                        }
                    }
                    /*if (!exist)
                    {
                        Console.WriteLine("The Employee Name does not exist!\n");
                    }*/
                

            }


            
                
            Console.WriteLine("Do you want to repeat the option Y / N ?");
            string optionresult = Console.ReadLine();
            if (optionresult == "Y")
            {
                goto startconsole;
            }

            


            /*Console.WriteLine("Pascal Pyramid program");

            for (int i = 0; i <= 5; ++i)
            {
                for (int j = 1; j <= i; ++j)
                {
                    Console.Write("{0}  {1}", i, j);
                }
                Console.WriteLine();
            }*/

        }  
        
        
    }
}
